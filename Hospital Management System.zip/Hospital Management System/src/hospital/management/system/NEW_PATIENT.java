package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.util.Date;

class BackgroundPanel extends JPanel {
    private Image backgroundImage;

    public BackgroundPanel(String imagePath) {
        backgroundImage = new ImageIcon(ClassLoader.getSystemResource(imagePath)).getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
    }
}

public class NEW_PATIENT extends JFrame implements ActionListener {
    JComboBox<String> comboBoxID, comboBoxGender;
    JTextField textFieldNumber, textName, textFieldDisease, textFieldDeposite;
    Choice c1;
    JLabel date;
    JButton b1, b2;

    NEW_PATIENT() {

        BackgroundPanel panel = new BackgroundPanel("icon/bg.jpg");
        panel.setLayout(null);
        setContentPane(panel);

        JPanel formPanel = new JPanel();
        formPanel.setBounds(100, 50, 650, 450);
        formPanel.setBackground(new Color(0, 0, 0, 60));
        formPanel.setLayout(null);
        panel.add(formPanel);

        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icon/patient.png"));
        Image image = imageIcon.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon imageIcon1 = new ImageIcon(image);
        JLabel label = new JLabel(imageIcon1);
        label.setBounds(470, -20, 200, 200);
        formPanel.add(label);

        JLabel labelName = new JLabel("NEW PATIENT FORM");
        labelName.setBounds(70, 10, 260, 30);
        labelName.setFont(new Font("Tahoma", Font.BOLD, 20));
        formPanel.add(labelName);

        JLabel labelID = new JLabel("ID :");
        labelID.setBounds(50, 50, 100, 20);
        labelID.setFont(new Font("Tahoma", Font.BOLD, 14));
        formPanel.add(labelID);

        comboBoxID = new JComboBox<>(new String[]{"Aadhar Card", "Voter Id", "Driving License"});
        comboBoxID.setBounds(180, 50, 150, 20);
        comboBoxID.setFont(new Font("Tahoma", Font.BOLD, 14));
        formPanel.add(comboBoxID);

        JLabel labelNumber = new JLabel("Number :");
        labelNumber.setBounds(50, 80, 100, 20);
        labelNumber.setFont(new Font("Tahoma", Font.BOLD, 14));
        formPanel.add(labelNumber);

        textFieldNumber = new JTextField();
        textFieldNumber.setBounds(180, 80, 150, 20);
        formPanel.add(textFieldNumber);

        JLabel labelName1 = new JLabel("Name :");
        labelName1.setBounds(50, 110, 100, 20);
        labelName1.setFont(new Font("Tahoma", Font.BOLD, 14));
        formPanel.add(labelName1);

        textName = new JTextField();
        textName.setBounds(180, 110, 150, 20);
        formPanel.add(textName);

        JLabel labelGender = new JLabel("Gender :");
        labelGender.setBounds(50, 140, 100, 20);
        labelGender.setFont(new Font("Tahoma", Font.BOLD, 14));
        formPanel.add(labelGender);

        comboBoxGender = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        comboBoxGender.setBounds(180, 140, 150, 20);
        comboBoxGender.setFont(new Font("Tahoma", Font.BOLD, 14));
        formPanel.add(comboBoxGender);

        JLabel labelDisease = new JLabel("Disease :");
        labelDisease.setBounds(50, 170, 100, 20);
        labelDisease.setFont(new Font("Tahoma", Font.BOLD, 14));
        formPanel.add(labelDisease);

        textFieldDisease = new JTextField();
        textFieldDisease.setBounds(180, 170, 150, 20);
        formPanel.add(textFieldDisease);

        JLabel labelRoom = new JLabel("Room :");
        labelRoom.setBounds(50, 200, 100, 20);
        labelRoom.setFont(new Font("Tahoma", Font.BOLD, 14));
        formPanel.add(labelRoom);

        c1 = new Choice();
        try {
            conn c = new conn();
            ResultSet resultSet = c.statement.executeQuery("SELECT room_no FROM Room WHERE Availablity = 'Available'");
            while (resultSet.next()) {
                c1.add(resultSet.getString("room_no" ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        c1.setBounds(180, 200, 150, 20);
        formPanel.add(c1);

        JLabel labelDate = new JLabel("Time :");
        labelDate.setBounds(50, 230, 100, 20);
        labelDate.setFont(new Font("Tahoma", Font.BOLD, 14));
        formPanel.add(labelDate);

        Date date1 = new Date();
        date = new JLabel("" + date1);
        date.setBounds(180, 230, 250, 20);
        date.setFont(new Font("Tahoma", Font.BOLD, 14));
        formPanel.add(date);

        JLabel labelDeposite = new JLabel("Deposite :");
        labelDeposite.setBounds(50, 260, 100, 20);
        labelDeposite.setFont(new Font("Tahoma", Font.BOLD, 14));
        formPanel.add(labelDeposite);

        textFieldDeposite = new JTextField();
        textFieldDeposite.setBounds(180, 260, 150, 20);
        formPanel.add(textFieldDeposite);

        b1 = new JButton("ADD");
        b1.setBounds(100, 320, 120, 30);
        b1.setForeground(Color.WHITE);
        b1.setBackground(Color.BLACK);
        b1.addActionListener(this);
        formPanel.add(b1);

        b2 = new JButton("Back");
        b2.setBounds(250, 320, 120, 30);
        b2.setForeground(Color.WHITE);
        b2.setBackground(Color.BLACK);
        b2.addActionListener(this);
        formPanel.add(b2);

        setUndecorated(false);
        setSize(850, 550);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            conn c = new conn();
            String s1 = (String) comboBoxID.getSelectedItem();
            String s2 = textFieldNumber.getText();
            String s3 = textName.getText();
            String s4 = (String) comboBoxGender.getSelectedItem();
            String s5 = textFieldDisease.getText();
            String s6 = c1.getSelectedItem();
            String s7 = date.getText();
            String s8 = textFieldDeposite.getText();

            try {
                String q = "INSERT INTO Patient_Info VALUES ('" + s1 + "', '" + s2 + "', '" + s3 + "', '" + s4 + "', '" + s5 + "', '" + s6 + "', '" + s7 + "', '" + s8 + "')";
                String q1 = "UPDATE Room SET Availablity = 'Occupied' WHERE room_no = '" + s6 + "'";
                c.statement.executeUpdate(q);
                c.statement.executeUpdate(q1);
                JOptionPane.showMessageDialog(null, "Added Successfully");
                setVisible(false);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new NEW_PATIENT();
    }
}
